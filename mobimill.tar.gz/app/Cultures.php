<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cultures extends Model
{
    protected $table = 'Cultures';

}
