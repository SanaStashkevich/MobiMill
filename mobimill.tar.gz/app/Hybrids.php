<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hybrids extends Model
{
    protected $table = 'CornHybrids';
    //
}